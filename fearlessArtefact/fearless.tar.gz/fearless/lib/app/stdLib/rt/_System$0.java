package base;


public final class _System$0 implements System$0{
  public final Object mut$try$0(){ return new _CapTry$0(); }
}